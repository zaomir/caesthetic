/* @ds-bundle: {"format":4,"namespace":"CAESTHETICDesignSystem_b8a1ab","components":[{"name":"Accordion","sourcePath":"components/core/Accordion.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Panel","sourcePath":"components/core/Panel.jsx"},{"name":"PanelGrid","sourcePath":"components/core/Panel.jsx"},{"name":"CaseRow","sourcePath":"components/data/CaseRow.jsx"},{"name":"ComparisonTable","sourcePath":"components/data/ComparisonTable.jsx"},{"name":"Connect4Diagram","sourcePath":"components/data/Connect4Diagram.jsx"},{"name":"ConsistencyMatrix","sourcePath":"components/data/ConsistencyMatrix.jsx"},{"name":"EvidenceStrip","sourcePath":"components/data/EvidenceStrip.jsx"},{"name":"PriceBlock","sourcePath":"components/data/PriceBlock.jsx"},{"name":"PriorityList","sourcePath":"components/data/PriorityList.jsx"},{"name":"DoNotDo","sourcePath":"components/data/PriorityList.jsx"},{"name":"ScoreCardGrid","sourcePath":"components/data/ScoreCardGrid.jsx"},{"name":"FormField","sourcePath":"components/forms/FormField.jsx"},{"name":"FormSuccess","sourcePath":"components/forms/FormField.jsx"},{"name":"FormError","sourcePath":"components/forms/FormField.jsx"},{"name":"FormLoading","sourcePath":"components/forms/FormField.jsx"},{"name":"Footer","sourcePath":"components/navigation/Footer.jsx"},{"name":"Header","sourcePath":"components/navigation/Header.jsx"}],"sourceHashes":{"components/core/Accordion.jsx":"24b168b6155a","components/core/Badge.jsx":"61ac73300d32","components/core/Button.jsx":"9f4e56bba706","components/core/Panel.jsx":"2f562f0d1353","components/data/CaseRow.jsx":"ec87d04bca06","components/data/ComparisonTable.jsx":"a66e4e766664","components/data/Connect4Diagram.jsx":"3a8417ddf9f0","components/data/ConsistencyMatrix.jsx":"5e31fdc4b2d9","components/data/EvidenceStrip.jsx":"b1238a0ff506","components/data/PriceBlock.jsx":"909ba726a989","components/data/PriorityList.jsx":"b4edcdcdd387","components/data/ScoreCardGrid.jsx":"4c995265949d","components/forms/FormField.jsx":"3eb2514bb32c","components/navigation/Footer.jsx":"a32e5f763476","components/navigation/Header.jsx":"cf4452fc9f2d"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.CAESTHETICDesignSystem_b8a1ab = window.CAESTHETICDesignSystem_b8a1ab || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Accordion.jsx
try { (() => {
function Accordion({
  items
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid var(--cae-border-strong)"
    }
  }, items.map((it, i) => /*#__PURE__*/React.createElement("details", {
    key: i,
    style: {
      padding: "20px 0",
      borderBottom: "1px solid var(--cae-border)"
    }
  }, /*#__PURE__*/React.createElement("summary", {
    style: {
      cursor: "pointer",
      color: "var(--cae-text-strong)",
      fontFamily: "var(--cae-font-display)",
      fontSize: "var(--cae-text-xl)",
      minHeight: 48
    }
  }, it.q), /*#__PURE__*/React.createElement("p", {
    style: {
      maxWidth: "66ch",
      marginTop: 16,
      color: "var(--cae-muted)"
    }
  }, it.a))));
}
Object.assign(__ds_scope, { Accordion });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Accordion.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
const TONES = {
  default: {
    background: "var(--cae-bg-3)",
    color: "var(--cae-muted)"
  },
  accent: {
    background: "var(--cae-accent-light)",
    color: "var(--cae-accent)"
  },
  signal: {
    background: "var(--cae-signal-light)",
    color: "var(--cae-signal)"
  },
  positive: {
    background: "var(--cae-data-positive-bg)",
    color: "var(--cae-data-positive)"
  },
  negative: {
    background: "var(--cae-data-negative-bg)",
    color: "var(--cae-data-negative)"
  },
  warning: {
    background: "var(--cae-data-warning-bg)",
    color: "var(--cae-data-warning)"
  }
};
function Badge({
  tone = "default",
  children
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      padding: "3px 8px",
      fontFamily: "var(--cae-font)",
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      borderRadius: "var(--cae-radius-sm)",
      ...TONES[tone]
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
const VARIANTS = {
  primary: {
    background: "var(--cae-text-strong)",
    color: "var(--cae-bg)",
    borderColor: "var(--cae-text-strong)"
  },
  outline: {
    background: "transparent",
    color: "var(--cae-text-strong)",
    borderColor: "var(--cae-text-strong)"
  },
  accent: {
    background: "var(--cae-accent)",
    color: "var(--cae-bg)",
    borderColor: "var(--cae-accent)"
  },
  signal: {
    background: "var(--cae-signal)",
    color: "var(--cae-bg)",
    borderColor: "var(--cae-signal)"
  },
  ghost: {
    background: "transparent",
    color: "var(--cae-muted)",
    borderColor: "var(--cae-border)"
  },
  "outline-inv": {
    background: "transparent",
    color: "var(--cae-bg)",
    borderColor: "var(--cae-bg)"
  }
};
const HOVER = {
  primary: {
    background: "var(--cae-accent)",
    borderColor: "var(--cae-accent)"
  },
  outline: {
    background: "var(--cae-text-strong)",
    color: "var(--cae-bg)"
  },
  accent: {
    background: "var(--cae-accent-2)",
    borderColor: "var(--cae-accent-2)"
  },
  signal: {
    background: "var(--cae-signal-2)",
    borderColor: "var(--cae-signal-2)"
  },
  ghost: {
    borderColor: "var(--cae-text-strong)",
    color: "var(--cae-text-strong)"
  },
  "outline-inv": {
    background: "var(--cae-bg)",
    color: "var(--cae-text-strong)"
  }
};
function Button({
  variant = "primary",
  as = "button",
  href,
  disabled,
  loading,
  children,
  onClick
}) {
  const [hover, setHover] = React.useState(false);
  const Tag = as === "a" ? "a" : "button";
  const base = {
    minWidth: 44,
    maxWidth: "100%",
    overflowWrap: "anywhere",
    textAlign: "center",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    minHeight: 48,
    padding: "12px 22px",
    fontFamily: "var(--cae-font)",
    fontSize: "1rem",
    fontWeight: 700,
    border: "1px solid transparent",
    borderRadius: "var(--cae-radius-sm)",
    cursor: disabled ? "not-allowed" : "pointer",
    textDecoration: "none",
    opacity: disabled ? 0.6 : 1,
    transition: "background 140ms var(--cae-ease), color 140ms var(--cae-ease), border-color 140ms var(--cae-ease)",
    ...VARIANTS[variant],
    ...(hover && !disabled ? HOVER[variant] : {})
  };
  return /*#__PURE__*/React.createElement(Tag, {
    href: as === "a" ? href : undefined,
    disabled: as === "button" ? disabled : undefined,
    style: base,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onClick: onClick
  }, loading ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 16,
      height: 16,
      border: "2px solid currentColor",
      borderTopColor: "transparent",
      borderRadius: "50%",
      animation: "cae-spin 0.7s linear infinite"
    }
  }) : null, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Panel.jsx
try { (() => {
function Panel({
  num,
  title,
  children,
  href,
  variant = "default"
}) {
  const stat = variant === "stat";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: stat ? "24px" : "32px 24px",
      borderRight: "1px solid var(--cae-border)",
      borderBottom: "1px solid var(--cae-border)",
      minWidth: 0,
      minHeight: stat ? "auto" : 220,
      display: "flex",
      flexDirection: "column"
    }
  }, num ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--cae-font-mono)",
      fontSize: "var(--cae-text-xs)",
      fontWeight: 500,
      letterSpacing: "0.1em",
      color: "var(--cae-signal)",
      marginBottom: 48,
      display: "block"
    }
  }, num) : null, title ? /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--cae-font-display)",
      fontSize: "1.5rem",
      fontWeight: 400,
      color: "var(--cae-text-strong)",
      letterSpacing: "-0.02em",
      marginBottom: 12
    }
  }, title) : null, /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--cae-muted)",
      fontSize: "var(--cae-text-sm)",
      lineHeight: 1.6,
      flex: 1,
      overflowWrap: "anywhere"
    }
  }, children), href ? /*#__PURE__*/React.createElement("a", {
    href: href,
    style: {
      display: "inline-block",
      marginTop: 16,
      fontSize: "var(--cae-text-xs)",
      fontWeight: 600,
      color: "var(--cae-accent)"
    }
  }, "Learn more \u2192") : null);
}
function PanelGrid({
  columns = 3,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: `repeat(${columns}, 1fr)`,
      borderTop: "1px solid var(--cae-border-strong)",
      borderLeft: "1px solid var(--cae-border)"
    }
  }, children);
}
Object.assign(__ds_scope, { Panel, PanelGrid });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Panel.jsx", error: String((e && e.message) || e) }); }

// components/data/CaseRow.jsx
try { (() => {
function CaseRow({
  meta,
  title,
  situation,
  approach,
  result,
  sourceNote,
  href
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1.2fr 1fr",
      gap: 40,
      padding: "32px 0",
      borderBottom: "1px solid var(--cae-border-strong)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "0 0 12px",
      color: "var(--cae-muted)",
      fontSize: "0.875rem"
    }
  }, meta), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: "0 0 20px",
      maxWidth: "32ch",
      fontSize: "clamp(1.5rem,2.3vw,2rem)",
      lineHeight: 1.2,
      fontFamily: "var(--cae-font-display)",
      fontWeight: 400,
      color: "var(--cae-text-strong)"
    }
  }, title), /*#__PURE__*/React.createElement("strong", {
    style: {
      display: "block",
      marginBottom: 8,
      color: "var(--cae-muted-2)",
      fontSize: "0.875rem",
      fontWeight: 600
    }
  }, "Situation"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "0 0 20px"
    }
  }, situation), /*#__PURE__*/React.createElement("strong", {
    style: {
      display: "block",
      marginBottom: 8,
      color: "var(--cae-muted-2)",
      fontSize: "0.875rem",
      fontWeight: 600
    }
  }, "Approach"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, approach)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-start",
      padding: 24,
      background: "var(--cae-bg-2)"
    }
  }, result ? /*#__PURE__*/React.createElement("div", {
    style: {
      width: "100%"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      marginBottom: 8,
      color: "var(--cae-muted-2)",
      fontSize: "0.875rem",
      fontWeight: 600
    }
  }, "Supported result"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "8px 0",
      color: "var(--cae-signal)",
      fontWeight: 600,
      fontSize: "1.25rem"
    }
  }, result)) : /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--cae-muted)",
      fontSize: "0.875rem"
    }
  }, "Supported result not yet published \u2014 see source note."), sourceNote ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "20px 0 0",
      paddingTop: 20,
      borderTop: "1px solid var(--cae-border)",
      color: "var(--cae-muted)",
      fontSize: "0.875rem",
      width: "100%"
    }
  }, sourceNote) : null, /*#__PURE__*/React.createElement("a", {
    href: href,
    style: {
      marginTop: "auto",
      paddingTop: 20,
      fontWeight: 600,
      color: "var(--cae-text-strong)"
    }
  }, "Read the case \u2192")));
}
Object.assign(__ds_scope, { CaseRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/CaseRow.jsx", error: String((e && e.message) || e) }); }

// components/data/ComparisonTable.jsx
try { (() => {
function ComparisonTable({
  columns,
  rows,
  highlightCol
}) {
  return /*#__PURE__*/React.createElement("table", {
    style: {
      width: "100%",
      borderCollapse: "collapse",
      fontSize: "var(--cae-text-sm)"
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      background: "var(--cae-accent)",
      color: "var(--cae-bg)"
    }
  }, columns.map((c, i) => /*#__PURE__*/React.createElement("th", {
    key: i,
    style: {
      padding: "12px 20px",
      fontFamily: "var(--cae-font)",
      fontSize: "var(--cae-text-xs)",
      fontWeight: 700,
      letterSpacing: "0.08em",
      textAlign: "left",
      background: i === highlightCol ? "var(--cae-signal)" : undefined
    }
  }, c)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, ri) => /*#__PURE__*/React.createElement("tr", {
    key: ri,
    style: {
      borderBottom: "1px solid var(--cae-border)"
    }
  }, r.map((cell, ci) => /*#__PURE__*/React.createElement("td", {
    key: ci,
    style: {
      padding: "12px 20px",
      borderRight: ci < r.length - 1 ? "1px solid var(--cae-border)" : "none",
      color: ci === 0 ? "var(--cae-text-strong)" : "var(--cae-muted)",
      fontWeight: ci === 0 ? 500 : 400,
      background: ci === highlightCol ? "var(--cae-signal-light)" : undefined
    }
  }, cell === true ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--cae-data-positive)",
      fontWeight: 700
    }
  }, "\u2713") : cell === false ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--cae-data-negative)",
      fontWeight: 700
    }
  }, "\u2715") : cell))))));
}
Object.assign(__ds_scope, { ComparisonTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ComparisonTable.jsx", error: String((e && e.message) || e) }); }

// components/data/Connect4Diagram.jsx
try { (() => {
const DEFAULT_SURFACES = [{
  num: "01",
  title: "Search / GBP",
  sub: "Discovery"
}, {
  num: "02",
  title: "Website",
  sub: "Evaluation"
}, {
  num: "03",
  title: "Social",
  sub: "Trust"
}, {
  num: "04",
  title: "Reputation / Reviews",
  sub: "Decision"
}];
function Connect4Diagram({
  surfaces = DEFAULT_SURFACES,
  activeIndex,
  faultIndex
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: `repeat(${surfaces.length}, 1fr)`,
      borderTop: "1px solid var(--cae-border)",
      borderBottom: "1px solid var(--cae-border)"
    }
  }, surfaces.map((s, i) => {
    const isActive = i === activeIndex,
      isFault = i === faultIndex;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        padding: "20px 16px",
        borderRight: i < surfaces.length - 1 ? "1px solid var(--cae-border)" : "none",
        borderLeft: "3px solid transparent",
        cursor: "default",
        background: isFault ? "var(--cae-signal-light)" : isActive ? "var(--cae-accent-light)" : undefined,
        borderLeftColor: isFault ? "var(--cae-signal)" : isActive ? "var(--cae-accent)" : "transparent"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "block",
        fontFamily: "var(--cae-font-mono)",
        fontSize: 10,
        color: "var(--cae-muted-2)",
        marginBottom: 12
      }
    }, s.num), /*#__PURE__*/React.createElement("span", {
      style: {
        display: "block",
        fontFamily: "var(--cae-font)",
        fontSize: "var(--cae-text-sm)",
        fontWeight: 600,
        color: isFault ? "var(--cae-signal)" : isActive ? "var(--cae-accent)" : "var(--cae-text-strong)"
      }
    }, s.title), /*#__PURE__*/React.createElement("span", {
      style: {
        display: "block",
        fontSize: "0.875rem",
        color: "var(--cae-muted-2)",
        marginTop: 3
      }
    }, s.sub));
  }));
}
Object.assign(__ds_scope, { Connect4Diagram });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Connect4Diagram.jsx", error: String((e && e.message) || e) }); }

// components/data/ConsistencyMatrix.jsx
try { (() => {
const ICON = {
  yes: "✓",
  no: "✕",
  partial: "△"
};
const COLOR = {
  yes: "var(--cae-data-positive)",
  no: "var(--cae-data-negative)",
  partial: "var(--cae-data-warning)"
};
function ConsistencyMatrix({
  rows,
  surfaces = ["Search / GBP", "Website", "Social", "Reputation"]
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      overflowX: "auto"
    }
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      width: "100%",
      minWidth: 640,
      borderCollapse: "collapse",
      fontSize: "var(--cae-text-sm)"
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: "left",
      padding: "12px 16px",
      borderBottom: "2px solid var(--cae-border-strong)",
      fontFamily: "var(--cae-font-mono)",
      fontSize: "var(--cae-text-xs)",
      color: "var(--cae-muted)",
      textTransform: "uppercase"
    }
  }, "Attribute"), surfaces.map(s => /*#__PURE__*/React.createElement("th", {
    key: s,
    style: {
      textAlign: "center",
      padding: "12px 16px",
      borderBottom: "2px solid var(--cae-border-strong)",
      fontFamily: "var(--cae-font-mono)",
      fontSize: "var(--cae-text-xs)",
      color: "var(--cae-muted)",
      textTransform: "uppercase"
    }
  }, s)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    style: {
      borderBottom: "1px solid var(--cae-border)"
    }
  }, /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: "left",
      padding: "12px 16px",
      fontWeight: 500,
      color: "var(--cae-text-strong)"
    }
  }, r.attribute), r.values.map((v, j) => /*#__PURE__*/React.createElement("td", {
    key: j,
    style: {
      textAlign: "center",
      padding: "12px 16px",
      background: v === "no" ? "var(--cae-data-negative-bg)" : v === "partial" ? "var(--cae-data-warning-bg)" : undefined
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: COLOR[v],
      fontWeight: 700
    }
  }, ICON[v]))))))));
}
Object.assign(__ds_scope, { ConsistencyMatrix });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ConsistencyMatrix.jsx", error: String((e && e.message) || e) }); }

// components/data/EvidenceStrip.jsx
try { (() => {
function EvidenceStrip({
  cells
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: `repeat(${cells.length}, 1fr)`,
      border: "1px solid var(--cae-border-strong)",
      background: "var(--cae-bg)"
    }
  }, cells.map((c, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: "20px",
      borderRight: i < cells.length - 1 ? "1px solid var(--cae-border)" : "none",
      display: "flex",
      flexDirection: "column",
      gap: 4,
      ...(c.priority ? {
        background: "var(--cae-signal-light)",
        borderLeft: "3px solid var(--cae-signal)"
      } : {})
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--cae-font)",
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      color: "var(--cae-muted-2)"
    }
  }, c.label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--cae-font-mono)",
      fontSize: "1.75rem",
      fontWeight: 500,
      lineHeight: 1,
      color: c.status === "positive" ? "var(--cae-data-positive)" : c.status === "negative" ? "var(--cae-data-negative)" : c.status === "warning" ? "var(--cae-data-warning)" : "var(--cae-text-strong)"
    }
  }, c.value, c.of ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "0.7em",
      color: "var(--cae-muted-2)"
    }
  }, " / ", c.of) : null), c.unit ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--cae-font-mono)",
      fontSize: "var(--cae-text-xs)",
      color: "var(--cae-muted-2)"
    }
  }, c.unit) : null, c.sub ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "0.875rem",
      color: "var(--cae-muted-2)"
    }
  }, c.sub) : null)));
}
Object.assign(__ds_scope, { EvidenceStrip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/EvidenceStrip.jsx", error: String((e && e.message) || e) }); }

// components/data/PriceBlock.jsx
try { (() => {
function PriceBlock({
  kicker,
  amount,
  title,
  children,
  checkCredit,
  actions
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "clamp(1.75rem, 4vw, 3rem)",
      background: "var(--cae-bg-dark)",
      color: "var(--cae-bg)"
    }
  }, kicker ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--cae-font)",
      fontSize: "var(--cae-text-xs)",
      fontWeight: 700,
      letterSpacing: "0.18em",
      textTransform: "uppercase",
      color: "var(--cae-signal-light)",
      margin: "0 0 16px"
    }
  }, kicker) : null, amount ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--cae-font-display)",
      fontSize: "clamp(2.5rem,6vw,3.5rem)",
      fontWeight: 300,
      margin: "16px 0"
    }
  }, amount) : null, title ? /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--cae-font-display)",
      fontWeight: 300,
      fontSize: "clamp(2rem,4vw,3.8rem)",
      lineHeight: 1,
      color: "var(--cae-bg)",
      marginBottom: 12
    }
  }, title) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "65ch"
    }
  }, children), checkCredit ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 24,
      padding: "clamp(1.5rem,3vw,2rem)",
      border: "1px solid var(--cae-border-data)"
    }
  }, checkCredit) : null, actions ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 12,
      marginTop: 24
    }
  }, actions) : null);
}
Object.assign(__ds_scope, { PriceBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/PriceBlock.jsx", error: String((e && e.message) || e) }); }

// components/data/PriorityList.jsx
try { (() => {
function PriorityList({
  items
}) {
  return /*#__PURE__*/React.createElement("ol", {
    style: {
      marginTop: 28,
      borderTop: "2px solid var(--cae-border-strong)"
    }
  }, items.map((it, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      display: "grid",
      gridTemplateColumns: "3rem 1fr",
      gap: 20,
      padding: "24px 0",
      borderBottom: "1px solid var(--cae-border)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--cae-font-mono)",
      color: "var(--cae-signal)"
    }
  }, String(i + 1).padStart(2, "0")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--cae-font-display)",
      fontSize: "var(--cae-text-xl)",
      fontWeight: 400,
      marginBottom: 8
    }
  }, it.title), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--cae-muted)",
      fontSize: "var(--cae-text-sm)",
      lineHeight: 1.6,
      margin: 0
    }
  }, it.detail)))));
}
function DoNotDo({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 28,
      padding: 24,
      background: "var(--cae-signal-light)",
      borderLeft: "2px solid var(--cae-signal)"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: "var(--cae-font-display)",
      fontSize: "var(--cae-text-xl)"
    }
  }, children));
}
Object.assign(__ds_scope, { PriorityList, DoNotDo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/PriorityList.jsx", error: String((e && e.message) || e) }); }

// components/data/ScoreCardGrid.jsx
try { (() => {
function ScoreCardGrid({
  score,
  of = 100,
  cards
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "auto 1fr",
      gap: "8px 20px",
      alignItems: "baseline",
      paddingTop: 20,
      borderTop: "2px solid var(--cae-border-strong)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--cae-font-mono)",
      textTransform: "uppercase",
      color: "var(--cae-muted-2)",
      fontSize: "var(--cae-text-xs)"
    }
  }, "Growth Score"), /*#__PURE__*/React.createElement("strong", {
    style: {
      fontFamily: "var(--cae-font-display)",
      fontSize: "clamp(2rem,6vw,4rem)",
      fontWeight: 400
    }
  }, score, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "1.25rem",
      color: "var(--cae-muted-2)"
    }
  }, " / ", of))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: `repeat(${cards.length}, 1fr)`,
      marginTop: 32,
      borderTop: "2px solid var(--cae-border-strong)",
      borderBottom: "1px solid var(--cae-border-strong)"
    }
  }, cards.map((c, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: 20,
      borderRight: i < cards.length - 1 ? "1px solid var(--cae-border)" : "none"
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      display: "block",
      fontFamily: "var(--cae-font-mono)",
      fontSize: "var(--cae-text-lg)",
      color: "var(--cae-accent)",
      marginBottom: 16
    }
  }, c.value), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: "var(--cae-font-display)",
      fontSize: "var(--cae-text-xl)",
      fontWeight: 400
    }
  }, c.label)))));
}
Object.assign(__ds_scope, { ScoreCardGrid });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ScoreCardGrid.jsx", error: String((e && e.message) || e) }); }

// components/forms/FormField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const fieldBase = {
  width: "100%",
  padding: "13px 16px",
  border: "1px solid var(--cae-border)",
  background: "var(--cae-bg)",
  fontFamily: "var(--cae-font)",
  fontSize: "var(--cae-text-sm)",
  color: "var(--cae-text)",
  borderRadius: "var(--cae-radius)"
};
function FormField({
  label,
  hint,
  error,
  type = "text",
  as = "input",
  options,
  ...rest
}) {
  const Tag = as;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "grid",
      gap: 8,
      fontFamily: "var(--cae-font)",
      fontSize: "var(--cae-text-xs)",
      fontWeight: 600,
      letterSpacing: "0.06em",
      color: "var(--cae-text-strong)"
    }
  }, /*#__PURE__*/React.createElement("span", null, label, " ", hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 400,
      color: "var(--cae-muted-2)",
      letterSpacing: 0
    }
  }, hint) : null), as === "select" ? /*#__PURE__*/React.createElement("select", _extends({
    style: {
      ...fieldBase,
      minHeight: 48
    }
  }, rest), options.map(o => /*#__PURE__*/React.createElement("option", {
    key: o,
    value: o
  }, o))) : as === "textarea" ? /*#__PURE__*/React.createElement("textarea", _extends({
    style: {
      ...fieldBase,
      minHeight: 130,
      resize: "vertical"
    }
  }, rest)) : /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    style: {
      ...fieldBase,
      minHeight: 48,
      borderColor: error ? "var(--cae-data-negative)" : "var(--cae-border)"
    }
  }, rest)), error ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "0.875rem",
      color: "var(--cae-data-negative)"
    }
  }, error) : null);
}
function FormSuccess({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "24px 20px",
      background: "var(--cae-data-positive-bg)",
      border: "1px solid var(--cae-data-positive)",
      borderRadius: "var(--cae-radius)",
      color: "var(--cae-data-positive)",
      fontSize: "var(--cae-text-sm)"
    }
  }, children);
}
function FormError({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 20,
      background: "var(--cae-data-negative-bg)",
      border: "1px solid var(--cae-data-negative)",
      borderRadius: "var(--cae-radius)",
      color: "var(--cae-data-negative)",
      fontSize: "var(--cae-text-sm)"
    }
  }, children);
}
function FormLoading({
  children = "Sending…"
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      color: "var(--cae-muted)",
      fontSize: "var(--cae-text-sm)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 16,
      height: 16,
      border: "2px solid var(--cae-border)",
      borderTopColor: "var(--cae-accent)",
      borderRadius: "50%",
      animation: "cae-spin 0.7s linear infinite"
    }
  }), children);
}
Object.assign(__ds_scope, { FormField, FormSuccess, FormError, FormLoading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/FormField.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Footer.jsx
try { (() => {
function Footer({
  logoSrc = "assets/brand/logo-square.png"
}) {
  const col = {
    display: "flex",
    flexDirection: "column",
    gap: 8
  };
  const linkStyle = {
    fontSize: "var(--cae-text-sm)",
    color: "rgba(247,245,240,.6)",
    textDecoration: "none"
  };
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "var(--cae-bg-dark)",
      color: "var(--cae-text-strong-on-dark)",
      padding: "64px 0 24px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "var(--cae-wrap)",
      margin: "0 auto",
      display: "grid",
      gridTemplateColumns: "1.4fr .7fr .7fr .7fr",
      gap: 40,
      paddingBottom: 48,
      borderBottom: "1px solid rgba(247,245,240,.1)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("a", {
    href: "/",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      textDecoration: "none"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      border: "1px solid rgba(247,245,240,.1)",
      padding: 3,
      background: "var(--cae-bg-dark-2)"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: logoSrc,
    width: "34",
    height: "34",
    alt: ""
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--cae-font)",
      fontSize: "var(--cae-text-sm)",
      fontWeight: 800,
      letterSpacing: "0.16em"
    }
  }, "CAESTHETIC")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--cae-text-sm)",
      color: "rgba(247,245,240,.55)",
      maxWidth: "40ch",
      lineHeight: 1.65,
      margin: "16px 0"
    }
  }, "OXFORD PROJETS trading as CAESTHETIC. #100, 600 W 7th St, Los Angeles, California 90017, US."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--cae-text-sm)"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "mailto:info@caesthetic.com",
    style: linkStyle
  }, "info@caesthetic.com"))), /*#__PURE__*/React.createElement("div", {
    style: col
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: "0.14em",
      textTransform: "uppercase",
      color: "var(--cae-muted-on-dark)"
    }
  }, "Product"), /*#__PURE__*/React.createElement("a", {
    href: "/growth-score/",
    style: linkStyle
  }, "Free Growth Score"), /*#__PURE__*/React.createElement("a", {
    href: "/lead-to-revenue-check/",
    style: linkStyle
  }, "Lead-to-Revenue Check \xB7 $500"), /*#__PURE__*/React.createElement("a", {
    href: "/sprint/",
    style: linkStyle
  }, "30-Day Growth Sprint \xB7 $2,500"), /*#__PURE__*/React.createElement("a", {
    href: "/growth-system/",
    style: linkStyle
  }, "Growth System"), /*#__PURE__*/React.createElement("a", {
    href: "/pricing/",
    style: linkStyle
  }, "Pricing")), /*#__PURE__*/React.createElement("div", {
    style: col
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: "0.14em",
      textTransform: "uppercase",
      color: "var(--cae-muted-on-dark)"
    }
  }, "Company"), /*#__PURE__*/React.createElement("a", {
    href: "/about/",
    style: linkStyle
  }, "About"), /*#__PURE__*/React.createElement("a", {
    href: "/support/",
    style: linkStyle
  }, "Support"), /*#__PURE__*/React.createElement("a", {
    href: "/case-studies/",
    style: linkStyle
  }, "Case Studies")), /*#__PURE__*/React.createElement("div", {
    style: col
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: "0.14em",
      textTransform: "uppercase",
      color: "var(--cae-muted-on-dark)"
    }
  }, "Legal"), /*#__PURE__*/React.createElement("a", {
    href: "/legal/privacy/",
    style: linkStyle
  }, "Privacy"), /*#__PURE__*/React.createElement("a", {
    href: "/legal/terms/",
    style: linkStyle
  }, "Terms"), /*#__PURE__*/React.createElement("a", {
    href: "/legal/payment-terms/",
    style: linkStyle
  }, "Payment Terms"))), /*#__PURE__*/React.createElement("div", {
    style: {
      width: "var(--cae-wrap)",
      margin: "0 auto",
      paddingTop: 20,
      fontSize: "0.875rem",
      color: "rgba(247,245,240,.35)"
    }
  }, "\xA9 ", new Date().getFullYear(), " CAESTHETIC."));
}
Object.assign(__ds_scope, { Footer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Footer.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Header.jsx
try { (() => {
const links = [{
  href: "/growth-score/",
  label: "Growth Score"
}, {
  href: "/sprint/",
  label: "30-Day Sprint"
}, {
  href: "/growth-system/",
  label: "Growth System"
}, {
  href: "/case-studies/",
  label: "Case Studies"
}, {
  href: "/pricing/",
  label: "Pricing"
}, {
  href: "/about/",
  label: "About"
}, {
  href: "/support/",
  label: "Support"
}];
function Header({
  logoSrc = "assets/brand/logo-square.png",
  active
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 100,
      background: "var(--cae-bg)",
      borderBottom: "1px solid var(--cae-border)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "min(1600px, calc(100% - 40px))",
      margin: "0 auto",
      minHeight: 74,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "/",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      textDecoration: "none"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      border: "1px solid var(--cae-border)",
      padding: 3,
      flexShrink: 0,
      background: "var(--cae-bg)"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: logoSrc,
    width: "34",
    height: "34",
    style: {
      objectFit: "contain"
    },
    alt: ""
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--cae-font)",
      fontSize: "var(--cae-text-sm)",
      fontWeight: 800,
      letterSpacing: "0.16em",
      color: "var(--cae-text-strong)"
    }
  }, "CAESTHETIC"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--cae-font)",
      fontSize: "var(--cae-text-xs)",
      color: "var(--cae-muted-2)"
    }
  }, "Growth operating system for aesthetic practices"))), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 4,
      fontFamily: "var(--cae-font)",
      fontSize: "var(--cae-text-sm)",
      fontWeight: 500
    }
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l.href,
    href: l.href,
    style: {
      padding: "6px 10px",
      color: active === l.label ? "var(--cae-text-strong)" : "var(--cae-muted)",
      fontWeight: active === l.label ? 600 : 500,
      textDecoration: "none",
      borderRadius: "var(--cae-radius-sm)"
    }
  }, l.label)), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 12
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary",
    as: "a",
    href: "/growth-score/"
  }, "Get your Growth Score")))));
}
Object.assign(__ds_scope, { Header });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Header.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Accordion = __ds_scope.Accordion;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Panel = __ds_scope.Panel;

__ds_ns.PanelGrid = __ds_scope.PanelGrid;

__ds_ns.CaseRow = __ds_scope.CaseRow;

__ds_ns.ComparisonTable = __ds_scope.ComparisonTable;

__ds_ns.Connect4Diagram = __ds_scope.Connect4Diagram;

__ds_ns.ConsistencyMatrix = __ds_scope.ConsistencyMatrix;

__ds_ns.EvidenceStrip = __ds_scope.EvidenceStrip;

__ds_ns.PriceBlock = __ds_scope.PriceBlock;

__ds_ns.PriorityList = __ds_scope.PriorityList;

__ds_ns.DoNotDo = __ds_scope.DoNotDo;

__ds_ns.ScoreCardGrid = __ds_scope.ScoreCardGrid;

__ds_ns.FormField = __ds_scope.FormField;

__ds_ns.FormSuccess = __ds_scope.FormSuccess;

__ds_ns.FormError = __ds_scope.FormError;

__ds_ns.FormLoading = __ds_scope.FormLoading;

__ds_ns.Footer = __ds_scope.Footer;

__ds_ns.Header = __ds_scope.Header;

})();
