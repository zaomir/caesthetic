# CAESTHETIC — Design System

CAESTHETIC is a growth intelligence and managed-execution platform for aesthetic-clinic owners (med spas, dermatology, dental, injector practices). It diagnoses what limits growth across four public surfaces, tells owners what to fix first and what *not* to fund, implements the fix in a fixed-price 30-Day Sprint, and verifies whether the change produced measurable results. Public program name: **Connect4** — exactly four surfaces: Search/Google Business Profile, Website, Social, Reputation/Reviews. Cross-Surface Consistency is cross-cutting; Lead Intake and Paid Ads are separate layers, never a fifth scored surface.

Brand voice: **Clinical Editorial Intelligence** — a specialist diagnostic brief, not a SaaS dashboard. Calm, precise, evidence-led, editorial. Product ladder: free **Growth Score** → optional $500 **Lead-to-Revenue Check** → $2,500 **30-Day Growth Sprint** → optional recurring **Growth System**.

## Sources

- GitHub repo (primary): [`zaomir/grainee-v2`](https://github.com/zaomir/grainee-v2) — explore `site-caesthetic/` (the live site source) and `docs/ssot/CAESTHETIC_DESIGN_SYSTEM.md` (the canonical visual-system SSOT, v3.1.0) for anything this system doesn't cover yet.
  - `site-caesthetic/assets/css/tokens.css`, `caesthetic.css`, `connect4.css`, `case-studies.css`, `case-study-detail.css`, `growth.css` — component and token source.
  - `site-caesthetic/templates/header.html`, `footer.html` — canonical nav/footer markup.
  - `site-caesthetic/SITE_MAP.md`, `README.md`, `DESIGN.md` — product IA and design authority chain.
- Uploaded file: `uploads/logo-520.f0c2e66c28.png` — this is the **EXPERT Dental Studio** client logo (a CAESTHETIC customer), not the CAESTHETIC brand mark. It is not used anywhere in this system. The real CAESTHETIC logo (hexagonal "C" mark) was copied from the repo into `assets/brand/`.

Exploring the live repo further (it is a large multi-project monorepo) will surface more real copy, additional score-report variants and the RU/localization content that this initial build did not have room to fully mine.

## Index

- `styles.css` — root stylesheet; imports everything under `tokens/`.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `motion.css`, `base.css`.
- `assets/` — `brand/` (logo, favicon), `connect4/` (locked owner-approved diagrams), `case-studies/` (sample cover + placeholder), `img/` (hero mesh, butterfly mark, team portrait).
- `components/core/` — Button, Badge, Panel/PanelGrid, Accordion.
- `components/forms/` — FormField, FormSuccess, FormError, FormLoading.
- `components/navigation/` — Header, Footer.
- `components/data/` — EvidenceStrip, ScoreCardGrid, PriorityList/DoNotDo, ComparisonTable, PriceBlock, CaseRow, Connect4Diagram, ConsistencyMatrix.
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand groups in the Design System tab).
- `templates/growth-score-report/`, `templates/case-study/`, `templates/sprint-offer/` — full representative screens, responsive.

## Components

Button, Badge, Panel, PanelGrid, Accordion, FormField, FormSuccess, FormError, FormLoading, Header, Footer, EvidenceStrip, ScoreCardGrid, PriorityList, DoNotDo, ComparisonTable, PriceBlock, CaseRow, Connect4Diagram, ConsistencyMatrix.

### Intentional additions
- **ConsistencyMatrix** — not found verbatim in the source CSS. Built to satisfy the brief's "cross-surface consistency matrix" pattern, styled from the same evidence-table/data-color system already in use (`.cae-evidence-table`, `--cae-data-*`).

## Content fundamentals

- **Voice**: specialist, calm, accountable, analytical — a diagnostic brief, never a hype pitch. "Evidence → tension → discovery → agency," per the brand's own behavioral-communication standard.
- **Person**: mostly third-person/imperative ("Implement the agreed priority constraint…", "Correct categories, services and location details…"). Rare direct address ("Your electronic Order…") when addressing the owner directly in forms/offers. No "we're excited to..." marketing register.
- **Precision over hype**: prices, scope and claims are exact and hedged where evidence is incomplete — "may," "where applicable," explicit "illustrative"/"synthetic" labels on demo content. Never a fabricated statistic, guaranteed ranking, or invented testimonial.
- **No emoji.** No exclamation points as a register. Uppercase is reserved for short kickers/labels (tracked +0.08–0.18em), never for body copy or shouted CTAs.
- **Numbers carry units and status**: "$2,500 USD," "31% mobile form drop," "-22% in 60 days" — always paired with a source/date where the SSOT requires it, never bare or decorative.
- **Boundaries are stated explicitly**: pages routinely include a "what this does *not* include" list (no guaranteed rankings, no review incentives, no automatic ad-spend increase while a leak is open). This candor is part of the brand's credibility, not a legal afterthought.
- **Bilingual**: English is canonical; Russian localizations exist for some verticals (e.g. `/ru/salony-krasoty/`, Spoken RU report). Localized copy keeps the same register — evidence-led, not looser or more casual in translation.

## Visual foundations

- **Palette**: cool clinical paper background (`#F5F7F8`), near-black charcoal text/ink rules, **clinical navy** (`#1C3A4A`) as the structural/action accent, and a **restrained burgundy** (`#7B244B`) reserved for CTAs, priority flags and kicker text — never used decoratively or for a whole section background. Semantic data colors (positive green / negative red / warning amber / neutral slate) always ship with a text or icon label — color alone never carries meaning. A separate warm-paper palette (`#F0EDE6` "v3-paper") is scoped only to the historical owner-decision-report profile; it is not the marketing palette.
- **Type**: three families with distinct jobs — **Source Serif 4** (weights 300/400/600) for editorial display headings only, **IBM Plex Sans** (300–700) for everything else — body, labels, buttons, nav, and **IBM Plex Mono** (400/500) for every number, score, timestamp and data value. H1–H3 use −0.03em tracking; kickers use uppercase +0.08–0.18em tracking. Fonts are loaded from Google Fonts CDN (see `tokens/typography.css` `@import`) — no local webfont files were provided in the source.
- **Spacing**: an 8-rooted scale — 4/8/12/16/20/24/28/32/40/48/64/80/96px. Sections use 96px block padding (64px on mobile).
- **Layout**: ruled editorial ledgers, not card grids. Content sits inside grids bordered by 1px rules (`border-top`/`border-right`) rather than boxed cards with shadows — **no drop shadows anywhere in the system**. Containers cap at 1180px default / 1440px wide / 880px narrow. Asymmetric splits (1.2/0.8, 0.85/1.15, 1.3/0.7) are preferred over even thirds.
- **Backgrounds**: flat only — `bg` (paper), `bg-2`/`bg-3` (tonal steps for section alternation and denser data), `bg-dark` (reversed editorial sections and the footer). No gradients, no photographic full-bleed hero, no hand-drawn illustration, no repeating pattern/texture on brand surfaces.
- **Corners & borders**: nearly square. Radius is 2px on buttons, 4px on form fields/panels, 6px on dialogs — editorial ledger panels use 0. Borders are 1px standard rules, 2–3px for meaningful structural emphasis (e.g. a burgundy left border flags a priority row).
- **Cards**: CAESTHETIC doesn't really have "cards" — it has ruled panels (`.cae-panel`) that are transparent, square and shadowless, separated by rules rather than boxed. Where an evidence/case panel needs a filled background it uses a flat tonal fill (`bg-2`/`bg-3`), never a shadow.
- **Motion**: purely functional — 140/220/380ms with `cubic-bezier(.25,0,.25,1)` (standard) or `cubic-bezier(0,0,.25,1)` (out). Fades and evidence-strip stagger-ins only; no bounce, no autoplay carousel, no decorative count-up. Reduced-motion disables all of it.
- **Hover/press states**: hover moves color one step darker/toward-accent (near-black → navy; burgundy → lighter burgundy on dark), never opacity-fades. Press states are not distinctly styled beyond the browser default; disabled state uses reduced opacity **plus** the `disabled`/`cursor:not-allowed` semantic, never color alone.
- **Imagery**: cool, clinical, unstaged — no warm beauty-spa stock photography. The one approved persona photo (Valerie Petra, point of contact) is a plain office portrait, square-cropped, bordered, not backlit or filtered. Connect4 diagrams and the "Where Clients Are Gained — and Lost" map are **locked raster PNGs** — exact bytes, no recolor/redraw/re-crop; treat them as immutable evidence artifacts, not editable UI.
- **Transparency/blur**: essentially unused on brand surfaces (the SSOT explicitly forbids `backdrop-filter` on the sticky header, since it breaks mobile drawer positioning). Rare exceptions are functional overlays (nav dropdown enter/exit), not decorative glass.

## Iconography

CAESTHETIC does not use an icon font, SVG icon library, or emoji. The system leans on **typography and rule geometry instead of icons**: numbered mono labels (`01`, `02`…), a mono `▼` dropdown arrow, and plain-text glyphs for state (`✓` / `✕` for comparison tables, `△` sometimes for warning). Where a real icon is unavoidable (e.g. a future settings/nav icon), match the stroke weight and precision of the rest of the system — this project intentionally does not introduce a borrowed icon set (Lucide/Heroicons/etc.) since the source never uses one. If a consuming project needs functional icons, pick a thin-stroke outline set (1.5px stroke, geometric, no fill) and flag the substitution.

## Fonts — substitution note

No local font files (`.ttf`/`.woff2`) were present in the source; the live site loads **Source Serif 4**, **IBM Plex Sans** and **IBM Plex Mono** directly from Google Fonts, and `tokens/typography.css` mirrors that exact `@import` URL. If you need true self-hosted/offline fonts, download the same three families from Google Fonts and swap the `@import` for local `@font-face` rules — no substitution was necessary since the source already specifies open, CDN-available families.

## Caveats & ask

- This build mined the CAESTHETIC-specific slice of a very large monorepo (13,000+ files). There is more real copy, more report variants (owner-decision-report v2/v3, Spoken RU/EN presentations) and localized (RU/ES/FR) marketing pages I did not have room to fully absorb — worth a follow-up pass if you want those covered.
- `ConsistencyMatrix` is my own addition (flagged above) — happy to redesign it if you have a real internal pattern for this.
- I built three representative templates (Growth Score Report, Case Study, 30-Day Sprint Offer) as fluid/responsive single documents rather than separate desktop+mobile files; let me know if you'd rather see literal mobile-width screenshots side by side.
- **Please iterate with me** — tell me which components feel off-brand, which real copy/report data I should pull in verbatim instead of illustrative placeholders, and whether the mobile nav drawer, multi-stage intake form and evidence-ledger accordion (currently only sketched in prose) should be built out as full interactive components next.
